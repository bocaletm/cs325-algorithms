Use the following command to run:
python3 stoogeSort.py
