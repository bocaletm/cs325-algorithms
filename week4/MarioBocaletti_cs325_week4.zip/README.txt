To test the schedule program, run:
python3 activitySelect.py
